These resources are *ONLY for INTERNAL usage* by the Instagram-API library developer team.

Do *NOT* ask us about them. Do *NOT* make support tickets about them. We will *ban* you.

Using this library is a *privilege* and we do *not* have to explain everything to every newbie who stumbles upon our repository.

If you want to join the team, then read for yourself what they do and try to figure it out on your own.
